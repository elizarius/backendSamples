print "Input True or False"

somecondition = input()
if somecondition:
 print "somecondition was True"
else:
 print "somecondition was False"
print "this line belongs to main level code block"
mjono ="Kalle"
mjono = mjono.replace("ll", "kk")
print mjono


# Using tabs to indent the same code
somecondition = input()
if somecondition:
    print "somecondition was True"
    print "foo"
else:
    print "*" * 40
print "this line belongs to main level code block"
