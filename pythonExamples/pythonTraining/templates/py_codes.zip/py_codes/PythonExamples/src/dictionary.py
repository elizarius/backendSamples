d = {"011207-XXXX" : "Auckland Ann", \
    "230867-XXXX" : "Balkac Ben", \
    "050380-XXXX" : "Carlton Simon"}
print d
d["230867-XXXX"] = "Wappu Kankkunen"
print d
del d["230867-XXXX"]
print d