name = raw_input("Give your name: ")
print name

#formatted output
account = "Nelli"
balance = 100.2367
print '%-10s %10.2f' % (account, balance)
