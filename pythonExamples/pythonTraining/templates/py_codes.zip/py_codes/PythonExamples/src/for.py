team = ("Henry", "Jack", "Mick", "Peter", "Sam", "Tom", "Walther")
for player in team :
    print player
for c in player:
    print c
    
for value in range(1,11):
    print value