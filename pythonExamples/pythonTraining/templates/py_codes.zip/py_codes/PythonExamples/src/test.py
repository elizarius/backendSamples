#import foo.bar

import foo.bar as foobar

foobar.bar()