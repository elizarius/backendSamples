myvariable = 0
Myvariable = "k"
_myvariable = 7
__myvariable ="l"
_my_400 = 400
_400 = 400 
____________________________foo = "foo"

#Example variable definitions:

number = 100
complexnumber = complex(1, 2)
somestring = "foobar"
value = function(1, 2, 3)
