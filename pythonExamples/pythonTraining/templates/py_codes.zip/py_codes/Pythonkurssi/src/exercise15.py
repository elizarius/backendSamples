# -*- coding: iso-8859-1 -*-
import sys

print "Platta: ", sys.platform
print "Argumentit: ", sys.argv
print "Polku: ", sys.path
print "Pyytt� versio: ", sys.version
print "C API: ", sys.api_version
print "Bittij�rjestys: ", sys.byteorder