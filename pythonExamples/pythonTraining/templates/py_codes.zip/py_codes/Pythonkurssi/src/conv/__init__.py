#! /usr/bin/python
# -*- coding: iso-8859-1 -*-

# __init__.py
# package example
# Copyright Tieturi Oy 2010

def init():
    "nothing here in this example"
    print "Initializer of converter package!"
    
init()