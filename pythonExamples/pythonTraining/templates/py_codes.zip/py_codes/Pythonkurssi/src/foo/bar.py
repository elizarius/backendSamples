def bar():
    print "Hello from module bar!"
    
def init():
    print "Initializer of bar"

init()