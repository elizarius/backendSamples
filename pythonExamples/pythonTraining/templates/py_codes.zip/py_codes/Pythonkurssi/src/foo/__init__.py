def init():
    print "Initializer of foo package!"
    
init()