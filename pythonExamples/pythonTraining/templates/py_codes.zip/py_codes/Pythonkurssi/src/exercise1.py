a = 10
print a
a = "Anssi"
print a
a = 100.45
print a
