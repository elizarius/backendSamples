for celsius in range(-100, 110, 10):
    print '%+-10d%+10.2f' % (celsius,  (1.8*celsius + 32))